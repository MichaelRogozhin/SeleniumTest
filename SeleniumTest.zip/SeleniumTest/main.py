from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from time import sleep

print("Тестирование начато.")

driver = webdriver.Firefox(executable_path='C:\\SeleniumTest\\Geckodriver\\geckodriver.exe')

driver.get("http://www.google.com")

elem = driver.find_element_by_name("q")
elem.send_keys("selenium")
elem.submit()

#пауза 5 сек.
sleep(5)

elem = driver.find_element_by_link_text("Ещё")
elem.click()

elem = driver.find_element_by_link_text("Картинки")
elem.click()

#пауза 5 сек.
sleep(5)

elem = driver.find_element_by_link_text("Все")
elem.click()


print("Тестирование завершено.")


